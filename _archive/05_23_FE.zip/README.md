# SCAVENGER RACE

### Setup

---

Clone the repository. Install packages. Launch.

```
$ npm i
$ npm run dev
```

### Todo to get to Alpha of the builder

---

- [x] ~~Componitize Sidebar~~ - 4/11/24
- [x] ~~Legs view~~ - 4/20/24, with 'todos'
- [ ] Tasks view
- [ ] Authentication
- [ ] Add DB
  - [ ] Link Users
  - [ ] Link Race
  - [ ] Link Tasks
  - [ ] Link Legs
  - [ ] Link Roles
