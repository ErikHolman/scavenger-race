export enum Status {
  'Not started',
  'In progress',
  'Completed',
}
