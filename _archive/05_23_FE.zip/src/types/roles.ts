export enum Roles {
  'admin',
  'driver',
  'judge',
  'racer',
  'spectator',
}
