// this is the inbetween leg component. AKA time to next leg.
// Needs global timer

export const Holding = () => {
  return <div>Holding Comp</div>;
};
