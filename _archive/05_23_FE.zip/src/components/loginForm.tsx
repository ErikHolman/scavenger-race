// this is the login form

export const Login = () => {
  return <div>Login form</div>;
};
